package com.naoh.whalechat.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.wear.compose.material3.AppScaffold
import androidx.wear.compose.material3.MaterialTheme
import androidx.wear.compose.material3.TimeText
import androidx.wear.compose.navigation.SwipeDismissableNavHost
import androidx.wear.compose.navigation.composable
import androidx.navigation.NavType
import androidx.navigation.navArgument
import androidx.wear.compose.navigation.rememberSwipeDismissableNavController
import com.naoh.whalechat.data.BuiltinPersonas
import com.naoh.whalechat.data.ChatEngine
import com.naoh.whalechat.data.PersonaField
import com.naoh.whalechat.data.PersonaSource
import com.naoh.whalechat.ui.theme.WhaleChatTheme

private object Routes {
    const val HOME = "home"
    const val CHAT = "chat"
    const val SETTINGS = "settings"
    const val SETTINGS_SPEECH = "settings/speech"

    /**
     * 显示设置二级页。三个显示开关都收在这一页。
     *
     * ⚠️ **主设置页那个入口隐藏了**（`SettingsScreen.SHOW_DISPLAY_SETTINGS_ENTRY`），
     * 但**这条路由必须保留** —— 要求「先隐藏、不删」，恢复入口时它得还在，
     * 否则点了入口进的是空白页。导航分支也一并留着。
     *
     * 和 [SETTINGS_SPEECH] 同级、同样**不带** `from` 参数：这一页的行为
     * 跟从哪一页进来的没有关系（理由见 `DisplaySettingsScreen` 的类注释）。
     */
    const val SETTINGS_DISPLAY = "settings/display"

    /**
     * 「关于」二级页。1.978 新增 —— 设置页那一格从一段文字换成卡片，点进这一页。
     *
     * 和 [SETTINGS_SPEECH] / [SETTINGS_DISPLAY] 同级、同样**不带** `from` 参数：
     * 这一页跟「从哪一页进来的」没有关系，从 ask 进设置和从 chat 进设置看到的是同一页。
     *
     * ⚠️ 它和 [SETTINGS] 的关系是「同前缀、不同路径」，**不受** [settings] 那个
     * `settings?from=` 查询参数的影响 —— 后者是 `settings` 后面接 `?`，
     * 这一条是后面接 `/about`，两条模板不会互相匹配。
     */
    const val SETTINGS_ABOUT = "settings/about"
    const val INPUT_API_KEY = "input/apikey"

    /** 智谱（GLM）的 Key 输入页。与 DeepSeek 那个同一个输入页，只是 InputTarget 不同。 */
    const val INPUT_ZHIPU_KEY = "input/zhipuapikey"
    const val INPUT_PROMPT = "input/prompt"

    /**
     * 通用接口（OpenAI 兼容 ASR）的三格。1.982 加回来。
     *
     * ⚠️ 命名沿用 1.0 的 `INPUT_ASR_*`：这一档全应用统称「通用接口」，
     * 但它在设置字段和 prefs 键上一直叫 `asr*`（`asrUrl` / `asr_url`），
     * 路由跟着字段名走 —— 换个叫法只会多一处对不上的地方。
     */
    const val INPUT_ASR_URL = "input/asrurl"
    const val INPUT_ASR_KEY = "input/asrkey"
    const val INPUT_ASR_MODEL = "input/asrmodel"

    const val INPUT_XFY_APPID = "input/xfyappid"
    const val INPUT_XFY_APIKEY = "input/xfyapikey"
    const val INPUT_XFY_APISECRET = "input/xfyapisecret"
    const val INPUT_CHAT = "input/chat"
    const val IMPORT_PHONE = "import/phone"

    /**
     * 设置页。**同一个页面，只是带了「从哪一页进来的」** ——
     * 从 chat 进来时，「手机扫码改凭证」下面会多一项「用手机管理人设」
     * （判据在 [SettingsScreen] 的注释里）。
     *
     * 用查询参数而不是 `settings/ask`、`settings/chat` 这样的并列路径：
     * 隔壁就有一个 `settings/speech`，再放两个同级段的话，
     * `settings/{page}` 这个模板会和 `settings/speech` 撞上 ——
     * 撞的结果是 speech 那一页永远打不开，而且是运行时才发现。
     */
    fun settings(from: HomePage) = "$SETTINGS?from=${from.name}"

    /** 和 [settings] 拼出来的必须逐字对应。 */
    const val SETTINGS_PATTERN = "$SETTINGS?from={from}"

    /**
     * 手机扫码那一页。[landing] 是**手机上落在哪一页**，取值见 [PhoneLanding]。
     *
     * 必须 `Uri.encode`：取值里有斜杠（`/p`、`/p/{uuid}`），
     * 不编的话斜杠会被路由当成路径分隔符，把这一截吃掉。
     */
    fun importPhone(landing: String) = "$IMPORT_PHONE?land=${Uri.encode(landing)}"

    /** 和 [importPhone] 拼出来的必须逐字对应。 */
    const val IMPORT_PHONE_PATTERN = "$IMPORT_PHONE?land={land}"

    // ------------------------------------------------------------------ 角色
    const val PERSONA_NEW = "persona/new"
    const val PERSONA_PRESET = "persona/preset"
    const val PERSONA_WAIT = "persona/wait"
    const val PERSONA_DETAIL = "persona/detail"
    const val INPUT_PERSONA_DESC = "input/persona-desc"

    /**
     * 角色会话**复用 `chat/{id}`**，不另开一条路由。
     *
     * 会话本身就是同一种东西（聊天页只需要一个会话 id），另开一条只会让
     * 「编辑重发」「停止生成」「语音」这些全都要分叉。角色与普通对话的差别只体现在
     * 数据里（`Conversation.personaId`）和气泡上那一行身份标签。
     */
    fun chat(id: String) = "$CHAT/$id"

    /**
     * 预设详情页。用查询参数而不是路径段：Navigation 对空值宽容，参数缺失时走默认值，
     * 不会出现「少一截就匹配不上模板」的意外（和前一条 [inputChat] 同一个理由）。
     */
    fun personaPreset(index: Int) = "$PERSONA_PRESET?index=$index"

    /**
     * 等待页。描述必须 `Uri.encode` —— 里面是中文，还可能带空格、斜杠、问号，
     * 不编的话这些字符会被路由当成结构字符吃掉。
     */
    fun personaWait(description: String, preset: Boolean): String =
        "$PERSONA_WAIT?description=${Uri.encode(description)}&preset=$preset"

    /** 等待页与预设详情页的路由模板，和上面两个拼出来的必须逐字对应。 */
    const val PERSONA_PRESET_PATTERN = "$PERSONA_PRESET?index={index}"
    const val PERSONA_WAIT_PATTERN = "$PERSONA_WAIT?description={description}&preset={preset}"

    fun inputPersonaField(personaId: String, field: PersonaField) =
        "input/persona-field/$personaId/${field.key}"

    const val INPUT_PERSONA_FIELD_PATTERN = "input/persona-field/{personaId}/{field}"

    /**
     * 角色详情页（逐块看人设 + 改那三个短字段）。
     *
     * 用路径段而不是查询参数：`personaId` 是 UUID，不会带需要转义的字符，
     * 而这条路由不带任何可选参数 —— 没有「少一截就匹配不上」的那种风险。
     */
    fun personaDetail(personaId: String) = "$PERSONA_DETAIL/$personaId"

    const val PERSONA_DETAIL_PATTERN = "$PERSONA_DETAIL/{personaId}"

    fun inputPresetField(index: Int, fieldKey: String) = "input/preset-field/$index/$fieldKey"
    const val INPUT_PRESET_FIELD_PATTERN = "input/preset-field/{index}/{fieldKey}"

    // ------------------------------------------------------------------ 大肥鱼皮肤
    /**
     * 皮肤选择页（2.34）。
     *
     * [restart] 是**模式开关**，不是「要重启哪个角色」：这一页永远只服务大肥鱼
     * （五个皮肤共用一个 id），所以值只用来区分首启模式 / 重开模式 ——
     * 非空即重开。仍然把 personaId 带过来，是为了将来真有多角色皮肤时不用改路由。
     *
     * 用查询参数而不是路径段，理由和 [personaPreset] 一样：Navigation 对空值宽容，
     * 参数缺失时走默认值，不会出现「少一截就匹配不上模板」的意外。
     *
     * ⚠️ 拼出去的值和 [FISH_SKIN_PATTERN] 必须逐字对应。
     */
    const val FISH_SKIN = "fish/skin"

    fun fishSkin(restartPersonaId: String? = null): String =
        "$FISH_SKIN?restart=${Uri.encode(restartPersonaId.orEmpty())}"

    const val FISH_SKIN_PATTERN = "$FISH_SKIN?restart={restart}"

    /**
     * 文字输入页。对话页那个键盘按钮进这一页。
     *
     * [draft] 是带过去待改的文字（录音还没发出去时按键盘按钮，那句识别结果
     * 就跟着过来）。必须 `Uri.encode` —— 中文会被编成 %XX，也可能带空格和
     * 斜杠，不编的话这些字符会被路由模板当成路径分隔符吃掉。
     *
     * [rewriteIndex] 非 null 表示这次是「编辑重发」：进来的是某条发过的提问。
     *
     * 两个参数**永远都带上**（没有就写空串 / -1），这样拼出来的 URL 和
     * [INPUT_CHAT_PATTERN] 逐字对应，不会出现「少一截参数就匹配不上模板」的意外。
     * Navigation 对空值本身是宽容的：声明的查询参数缺失时会被跳过，取到空串走默认值。
     */
    fun inputChat(id: String, draft: String = "", rewriteIndex: Int? = null): String {
        val rewrite = rewriteIndex?.toString() ?: REWRITE_NONE
        return "$INPUT_CHAT/$id?draft=${Uri.encode(draft)}&rewrite=$rewrite"
    }

    /** 「不是编辑重发」。用 -1 占位而不是省掉这一截，理由见 [inputChat]。 */
    const val REWRITE_NONE = "-1"

    /** 文字输入页的路由模板，和 [inputChat] 拼出来的必须逐字对应。 */
    const val INPUT_CHAT_PATTERN = "$INPUT_CHAT/{id}?draft={draft}&rewrite={rewrite}"
}

@Composable
fun WhaleChatApp() {
    WhaleChatTheme {
        AppScaffold(timeText = { TimeText() }) {
            val navController = rememberSwipeDismissableNavController()

            SwipeDismissableNavHost(
                navController = navController,
                startDestination = Routes.HOME,
            ) {

                composable(Routes.HOME) {
                    HomeScreen(
                        onOpenConversation = { navController.navigate(Routes.chat(it)) },
                        onNewConversation = {
                            navController.navigate(Routes.chat(ChatEngine.createConversation()))
                        },
                        // 首页两页各自把「我是谁」传上去，设置页据此决定要不要多给一项
                        onOpenSettings = { navController.navigate(Routes.settings(it)) },
                        onOpenPersona = { personaId ->
                            // ★ 2.34 首启拦截：第一次点大肥鱼 → 先挑皮肤，不直接进会话。
                            //
                            // 判据是 **id**（名字会随皮肤变，用名字判迟早失效）
                            // + `fishSkinChosen()`（**不能**用「prefs 里有没有 fish_skin_key」，
                            // 强覆盖会写 base，但用户一次都没选过 —— 见 ChatEngine 的注释）。
                            //
                            // 这一层（导航层）做判断，而不是把 navController 塞进 HomeScreen：
                            // 「点一个联系人」只有在导航层才变成一条路由，数据层不该认识路由。
                            // ★ 2.39：老用户（已有聊天记录、没选过皮肤）也一样先停一下 ——
                            //    选择页最上面会多一张「保留原来的大肥鱼」，人可以什么都不改。
                            if (personaId == BuiltinPersonas.BUILTIN_FISH_ID &&
                                (!ChatEngine.fishSkinChosen() ||
                                    ChatEngine.fishUpgradeChoicePending())
                            ) {
                                navController.navigate(Routes.fishSkin())
                            } else {
                                ChatEngine.openPersonaChat(personaId)?.let {
                                    navController.navigate(Routes.chat(it))
                                }
                            }
                        },
                        onRestartPersona = { personaId ->
                            // ★ 2.34：「重新开始」不再弹二次确认框，改成先进选择页
                            // （标题「换个性格，重新开始」）。选完皮肤才清空记录并进会话；
                            // 返回就什么都不做 —— 聊天记录一个字都不动。
                            //
                            // 只有**大肥鱼**会走到这里：HomeScreen 里已经按 id 分流，
                            // 其它角色照旧弹确认框、直接 restartPersona（它们没有皮肤可换）。
                            //
                            // 「先确认再清空」这道保险没有消失，只是换了位置：
                            // 选择页上写明了「聊天记录会清空」，而点卡片是用户自己按的。
                            navController.navigate(Routes.fishSkin(personaId))
                        },
                        onNewPersona = { navController.navigate(Routes.PERSONA_NEW) },
                        onOpenPersonaDetail = {
                            navController.navigate(Routes.personaDetail(it))
                        },
                    )
                }

                // ---------------------------------------------------------- 造人

                composable(Routes.PERSONA_NEW) {
                    PersonaNewScreen(
                        onDescribe = { navController.navigate(Routes.INPUT_PERSONA_DESC) },
                        onPickPreset = { navController.navigate(Routes.personaPreset(it)) },
                        // 与设置页那张「用手机管理人设」同一条路 —— 不另开路由、不另立说明。
                        onImportPersonas = {
                            navController.navigate(Routes.importPhone(PhoneLanding.PERSONAS))
                        },
                        // 「自己说一句」的接力棒：文字先落到 ChatEngine.personaDraft，
                        // 这一页重新回到前台才发起导航（见 ChatEngine.personaDraft 的注释）。
                        onDescriptionReady = { description ->
                            navController.navigate(Routes.personaWait(description, preset = false))
                        },
                    )
                }

                composable(
                    route = Routes.PERSONA_PRESET_PATTERN,
                    arguments = listOf(
                        navArgument("index") {
                            type = NavType.IntType
                            defaultValue = 0
                        },
                    ),
                ) { entry ->
                    PersonaPresetScreen(
                        presetIndex = entry.arguments?.getInt("index", 0) ?: 0,
                        onEditField = { fieldKey ->
                            val index = entry.arguments?.getInt("index", 0) ?: 0
                            navController.navigate(Routes.inputPresetField(index, fieldKey))
                        },
                        onGenerate = { description ->
                            navController.navigate(Routes.personaWait(description, preset = true))
                        },
                        // 成品预设（大肥鱼）：不联网、不生成，直接落库并进聊天页。
                        //
                        // ⚠️ 必须走 addBuiltinPersona（按 id 去重），**不能**直接
                        // createPersonaChat —— 成品预设的 id 是写死的常量，直接追加
                        // 会让「按两次添加」在通讯录里留下两条 id 相同的大肥鱼
                        // （2026-10-18 实测踩到）。理由见 ChatEngine.addBuiltinPersona。
                        //
                        // popUpTo(HOME) 和等待页那条**逐字一致**：用户点完「添加」，
                        // 最想看到的是 TA 开口；返回栈里不该留着预设页，否则从聊天页
                        // 返回会退回到一张「添加」页，而用户以为已经加过了。
                        onAddDirect = { persona ->
                            // ★ 2.34：从预设页「添加」一条还没选过皮肤的大肥鱼时，
                            // 同样先跳选择页。**必须先落库**（addBuiltinPersona 按 id 去重、
                            // 顺手把会话和 greeting 建好），否则接下来的 applyFishSkin
                            // 找不到这条 persona，会直接返回 null、屏幕上什么都没发生。
                            //
                            // 落库时用的是基础款；用户选完皮肤后，applyFishSkin 会把
                            // 「还没聊过」的会话里的开场白换成新皮肤的（见那边的注释）。
                            val needsSkinPick = persona.id == BuiltinPersonas.BUILTIN_FISH_ID &&
                                (!ChatEngine.fishSkinChosen() ||
                                    ChatEngine.fishUpgradeChoicePending())
                            val conversationId = ChatEngine.addBuiltinPersona(persona)
                            if (needsSkinPick) {
                                navController.navigate(Routes.fishSkin())
                            } else if (conversationId.isNotEmpty()) {
                                // popUpTo(HOME) 和等待页那条**逐字一致**：用户点完「添加」，
                                // 最想看到的是 TA 开口；返回栈里不该留着预设页。
                                navController.navigate(Routes.chat(conversationId)) {
                                    popUpTo(Routes.HOME) { inclusive = false }
                                }
                            }
                        },
                    )
                }

                composable(
                    route = Routes.PERSONA_WAIT_PATTERN,
                    arguments = listOf(
                        navArgument("description") {
                            type = NavType.StringType
                            defaultValue = ""
                        },
                        navArgument("preset") {
                            type = NavType.BoolType
                            defaultValue = false
                        },
                    ),
                ) { entry ->
                    PersonaWaitScreen(
                        // Navigation 会把 query 里的 %XX 自动解回来，这里拿到的是原文
                        description = entry.arguments?.getString("description").orEmpty(),
                        source = if (entry.arguments?.getBoolean("preset", false) == true) {
                            PersonaSource.PRESET
                        } else {
                            PersonaSource.CUSTOM
                        },
                        onReady = { conversationId ->
                            // **直接进聊天页，不要回第二页**：用户刚说完想要什么样的人，
                            // 最想看到的是 TA 开口（greeting 已经在建会话时上架了）。
                            //
                            // popUpTo(HOME) 是必要的：不弹的话返回栈里会留着
                            // 新建页 / 预设页 / 等待页三张，从聊天页返回会一张张退回去，
                            // 而用户的直觉是「回到角色列表」。HOME 本身保留（inclusive=false），
                            // 所以返回正好落在通讯录那一页上。
                            navController.navigate(Routes.chat(conversationId)) {
                                popUpTo(Routes.HOME) { inclusive = false }
                            }
                        },
                        // 取消 = 作废这次捏人**并且**退回上一页。作废那道规矩写在
                        // PersonaWaitScreen 自己的 BackHandler 里（和输入页的「离开 = 提交」
                        // 正好相反），这里只负责导航。
                        //
                        // **落点是「上一页」而不是第二页，这是拍板定的。**
                        // 两条路各自回各自的上一步，都是用户刚设置它的地方：
                        //   * 自己说一句 → 回「造一个角色」页，可以立刻改描述或换个预设重来；
                        //   * 预设详情   → 回预设详情页，之前改过的那四格**还在**，按生成即可。
                        // 直接 popUpTo(HOME) 会把这两处中间状态一起丢掉，用户得从头再填一遍。
                        // 所以别把这里「修」成直回第二页。
                        onBack = { navController.popBackStack() },
                    )
                }

                composable(Routes.INPUT_PERSONA_DESC) {
                    InputScreen(
                        target = InputTarget.PersonaDescription,
                        onDone = { navController.popBackStack() },
                    )
                }

                composable(Routes.INPUT_PERSONA_FIELD_PATTERN) { entry ->
                    val personaId = entry.arguments?.getString("personaId").orEmpty()
                    // 认不出来的字段名落回「名字」：这条路由理论上只有我们自己拼得出来，
                    // 但导航栈被恢复时参数是外部给的，兜一个默认值比崩掉好。
                    val field = PersonaField.fromKey(entry.arguments?.getString("field").orEmpty())
                        ?: PersonaField.NAME
                    InputScreen(
                        target = InputTarget.PersonaFieldEdit(personaId = personaId, field = field),
                        onDone = { navController.popBackStack() },
                    )
                }

                composable(Routes.PERSONA_DETAIL_PATTERN) { entry ->
                    val personaId = entry.arguments?.getString("personaId").orEmpty()
                    PersonaDetailScreen(
                        personaId = personaId,
                        onEditField = { field ->
                            navController.navigate(Routes.inputPersonaField(personaId, field))
                        },
                        // 长字段只能在手机上改 —— 说「去手机上改」却不给路，等于没说。
                        // 入口在详情页「用手机改」那一组里。
                        //
                        // 落在**这个角色自己的人设表单**上，不是凭证页：
                        // 用户是从 TA 的详情页点过来的，扫完还要自己在手机上再从凭证页
                        // 找一遍「管理角色→这个角色」，那这一步就白点了。
                        onOpenPhonePage = {
                            navController.navigate(
                                Routes.importPhone(PhoneLanding.persona(personaId)),
                            )
                        },
                    )
                }

                // 大肥鱼皮肤选择页（2.34）。两个入口共用这一条路由：
                //  * 首启：`restart` 为空串 → 标题「挑一条鱼」；
                //  * 「重新开始」/ 预设页「添加」：`restart` 非空 → 标题「换个性格，重新开始」。
                //
                // 空串**必须**在进页面之前折成 null：`restartPersonaId != null` 就是
                // 「要不要清空聊天记录」的判据，把空串当重开会把首启模式也变成删记录。
                composable(
                    route = Routes.FISH_SKIN_PATTERN,
                    arguments = listOf(
                        navArgument("restart") {
                            type = NavType.StringType
                            defaultValue = ""
                        },
                    ),
                ) { entry ->
                    FishSkinScreen(
                        restartPersonaId = entry.arguments
                            ?.getString("restart")
                            .orEmpty()
                            .ifBlank { null },
                        // 选完直接进会话。**popUpTo(HOME)**：两个入口都希望
                        // 「从聊天页返回 = 回到通讯录」，而不是退回选择页 —
                        // 退回去会让人以为没选成功，还多一次误触机会。
                        onPicked = { conversationId ->
                            navController.navigate(Routes.chat(conversationId)) {
                                popUpTo(Routes.HOME) { inclusive = false }
                            }
                        },
                    )
                }

                composable(Routes.INPUT_PRESET_FIELD_PATTERN) { entry ->
                    InputScreen(
                        target = InputTarget.PresetFieldEdit(
                            presetIndex = entry.arguments?.getInt("index", 0) ?: 0,
                            fieldKey = entry.arguments?.getString("fieldKey").orEmpty(),
                        ),
                        onDone = { navController.popBackStack() },
                    )
                }

                composable("${Routes.CHAT}/{id}") { entry ->
                    val id = entry.arguments?.getString("id").orEmpty()
                    ChatScreen(
                        conversationId = id,
                        onBack = { navController.popBackStack() },
                        onOpenTextInput = { draft, rewriteIndex ->
                            navController.navigate(Routes.inputChat(id, draft, rewriteIndex))
                        },
                        // 对话页那个齿轮算「从哪一页进来的」，判据是**这条会话有没有角色**：
                        // 带人设的会话本来就是从 chat 那一页进来的，在它的设置里
                        // 给出「管理人设」入口才对；一次纯提问的会话给 ask 那一份。
                        // 用会话自己的 `personaId` 判，不靠调用方传 —— 少一个会传错的参数。
                        onOpenSettings = {
                            val from = if (ChatEngine.find(id)?.personaId != null) {
                                HomePage.CHAT
                            } else {
                                HomePage.ASK
                            }
                            navController.navigate(Routes.settings(from))
                        },
                    )
                }

                composable(
                    route = Routes.SETTINGS_PATTERN,
                    arguments = listOf(
                        navArgument("from") {
                            type = NavType.StringType
                            defaultValue = HomePage.ASK.name
                        },
                    ),
                ) { entry ->
                    // 认不出来就落回 ASK。ASK 是「少一项」的那一份，
                    // 兜底少给一个入口，比多给一个来源不明的入口安全。
                    val origin = HomePage.entries.firstOrNull {
                        it.name == entry.arguments?.getString("from")
                    } ?: HomePage.ASK
                    SettingsScreen(
                        origin = origin,
                        onEditApiKey = { navController.navigate(Routes.INPUT_API_KEY) },
                        onEditZhipuKey = { navController.navigate(Routes.INPUT_ZHIPU_KEY) },
                        onEditPrompt = { navController.navigate(Routes.INPUT_PROMPT) },
                        onImportApiKey = {
                            navController.navigate(Routes.importPhone(PhoneLanding.CREDENTIALS))
                        },
                        onImportPersonas = {
                            navController.navigate(Routes.importPhone(PhoneLanding.PERSONAS))
                        },
                        onOpenSpeech = { navController.navigate(Routes.SETTINGS_SPEECH) },
                        onOpenDisplay = { navController.navigate(Routes.SETTINGS_DISPLAY) },
                        onOpenAbout = { navController.navigate(Routes.SETTINGS_ABOUT) },
                    )
                }

                composable(Routes.SETTINGS_SPEECH) {
                    SpeechSettingsScreen(
                        onBack = { navController.popBackStack() },
                        // 通用接口三格（1.982 加回来）。和讯飞那三格走同一个输入页 ——
                        // 只是 `InputTarget` 不同，标题/占位符/落盘各走各的分支。
                        onEditAsrUrl = { navController.navigate(Routes.INPUT_ASR_URL) },
                        onEditAsrKey = { navController.navigate(Routes.INPUT_ASR_KEY) },
                        onEditAsrModel = { navController.navigate(Routes.INPUT_ASR_MODEL) },
                        onEditXfyAppId = { navController.navigate(Routes.INPUT_XFY_APPID) },
                        onEditXfyApiKey = { navController.navigate(Routes.INPUT_XFY_APIKEY) },
                        onEditXfyApiSecret = { navController.navigate(Routes.INPUT_XFY_APISECRET) },
                    )
                }

                // 「关于」二级页。**不带 `from`** —— 这一页对两个来源是同一份内容。
                // 返回走 NavHost 默认的 popBackStack（返回手势和返回键都通）。
                // ⚠️ 1.980 起这一页**多了一条返回路径**：底部那颗 M3E 贴边「返回」
                // （`ScreenScaffold` 的 `edgeButton` 槽），它调的也是同一个
                // `popBackStack()` —— 三条路都通，不是三个不同的落点。
                composable(Routes.SETTINGS_ABOUT) {
                    AboutScreen(onBack = { navController.popBackStack() })
                }

                composable(Routes.SETTINGS_DISPLAY) {
                    DisplaySettingsScreen(onBack = { navController.popBackStack() })
                }

                composable(
                    route = Routes.IMPORT_PHONE_PATTERN,
                    arguments = listOf(
                        navArgument("land") {
                            type = NavType.StringType
                            defaultValue = PhoneLanding.CREDENTIALS
                        },
                    ),
                ) { entry ->
                    ImportKeyScreen(
                        // Navigation 会把 query 里的 %XX 自动解回来，这里拿到的是原文
                        landing = entry.arguments?.getString("land").orEmpty(),
                        onDone = { navController.popBackStack() },
                    )
                }

                composable(Routes.INPUT_API_KEY) {
                    InputScreen(
                        target = InputTarget.ApiKey,
                        onDone = { navController.popBackStack() },
                    )
                }

                composable(Routes.INPUT_ZHIPU_KEY) {
                    InputScreen(
                        target = InputTarget.ZhipuApiKey,
                        onDone = { navController.popBackStack() },
                    )
                }

                composable(Routes.INPUT_PROMPT) {
                    InputScreen(
                        target = InputTarget.SystemPrompt,
                        onDone = { navController.popBackStack() },
                    )
                }

                composable(Routes.INPUT_ASR_URL) {
                    InputScreen(
                        target = InputTarget.AsrUrl,
                        onDone = { navController.popBackStack() },
                    )
                }

                composable(Routes.INPUT_ASR_KEY) {
                    InputScreen(
                        target = InputTarget.AsrKey,
                        onDone = { navController.popBackStack() },
                    )
                }

                composable(Routes.INPUT_ASR_MODEL) {
                    InputScreen(
                        target = InputTarget.AsrModel,
                        onDone = { navController.popBackStack() },
                    )
                }

                composable(Routes.INPUT_XFY_APPID) {                    InputScreen(
                        target = InputTarget.XfyAppId,
                        onDone = { navController.popBackStack() },
                    )
                }

                composable(Routes.INPUT_XFY_APIKEY) {
                    InputScreen(
                        target = InputTarget.XfyApiKey,
                        onDone = { navController.popBackStack() },
                    )
                }

                composable(Routes.INPUT_XFY_APISECRET) {
                    InputScreen(
                        target = InputTarget.XfyApiSecret,
                        onDone = { navController.popBackStack() },
                    )
                }

                composable(
                    route = Routes.INPUT_CHAT_PATTERN,
                    // draft / rewrite 必须在这里声明，否则它们会被当成路由的一部分而不是
                    // 查询参数：带中文的那句识别结果经 Uri.encode 后是一串 %XX，
                    // 不声明的话匹配不上模板，导航会直接抛 IllegalArgumentException。
                    // 给了默认值，「没带草稿」「不是编辑重发」两条路就都能落地。
                    arguments = listOf(
                        navArgument("draft") {
                            type = NavType.StringType
                            defaultValue = ""
                        },
                        navArgument("rewrite") {
                            type = NavType.IntType
                            defaultValue = -1
                        },
                    ),
                ) { entry ->
                    val rewrite = entry.arguments?.getInt("rewrite", -1) ?: -1
                    InputScreen(
                        target = InputTarget.Chat(
                            conversationId = entry.arguments?.getString("id").orEmpty(),
                            // Navigation 会把 query 里的 %XX 自动解回来，这里拿到的是原文
                            draft = entry.arguments?.getString("draft").orEmpty(),
                            rewriteIndex = rewrite.takeIf { it >= 0 },
                        ),
                        onDone = { navController.popBackStack() },
                    )
                }
            }
        }
    }
}
