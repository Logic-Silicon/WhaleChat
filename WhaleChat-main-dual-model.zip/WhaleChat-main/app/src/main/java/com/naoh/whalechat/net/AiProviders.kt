package com.naoh.whalechat.net

import com.naoh.whalechat.BuildConfig

/**
 * 智谱（GLM）官方 API 地址（OpenAI 兼容的 `/chat/completions`）。
 *
 * 与 [DEEPSEEK_BASE_URL] 同一套做法：默认官方地址，联调时用 `-PzhipuChatBaseUrl`
 * 指到假服务（`build.gradle.kts` 读进 `BuildConfig.ZHIPU_CHAT_BASE_URL`），不用改源码。
 * ⚠️ 正式出包**绝不带**这个参数。
 */
val ZHIPU_BASE_URL: String = BuildConfig.ZHIPU_CHAT_BASE_URL.trimEnd('/')

/**
 * 智谱当前通用模型：GLM-4.6。
 *
 * 选它而不是 `glm-4-flash` 的理由：本应用「快答 / 深度思考」是一个**思考开关**
 * （`thinking.type = enabled/disabled`），不是两个模型名 —— 这个开关只有
 * GLM-4.5 及之后的模型支持，`glm-4-flash` 不认 `thinking` 参数。
 * 智谱侧也选一个支持思考开关的模型，语义才能和 DeepSeek 侧对齐。
 */
const val MODEL_ZHIPU = "glm-4.6"

/**
 * 对话模型供应商。
 *
 * ## 为什么抽象成「供应商」而不是「模型名」
 *
 * 两家的对话接口都是 OpenAI 兼容的 `/chat/completions`，请求/响应形状一致
 * （SSE 增量、`reasoning_content`、usage），[DeepSeekClient] 一套解析两边通用。
 * 真正要跟着换的只有三样：**基地址、模型名、Key**。所以抽象成供应商枚举，
 * 每家带自己的基地址与默认模型；Key 照旧留在 `SettingsStore`
 * （DeepSeek 沿用原有 `apiKey`，智谱新增 `zhipuApiKey`）。
 *
 * ## ask / chat 各存一档
 *
 * 与 `modeAsk` / `modeChat` 同一个套路：`Settings.providerAsk` / `providerChat`
 * 各存一份，设置页按来源一次只显示一组（`SettingsScreen` 的 `isChatOrigin`）。
 */
enum class AiProvider(
    val key: String,
    /** 设置页按钮与错误提示里显示的名字。 */
    val label: String,
    /** OpenAI 兼容基地址（不带尾斜杠，拼 `/chat/completions` 用）。 */
    val baseUrl: String,
    /** 这家的默认模型名。 */
    val defaultModel: String,
    /** 余额查询：智谱没有 DeepSeek 那个 `/user/balance` 端点，设置页据此隐藏余额卡。 */
    val supportsBalance: Boolean,
) {
    DEEPSEEK(
        key = "deepseek",
        label = "DeepSeek",
        baseUrl = DEEPSEEK_BASE_URL,
        defaultModel = MODEL_FLASH,
        supportsBalance = true,
    ),

    ZHIPU(
        key = "zhipu",
        label = "智谱 GLM",
        baseUrl = ZHIPU_BASE_URL,
        defaultModel = MODEL_ZHIPU,
        supportsBalance = false,
    ),
    ;

    companion object {
        /**
         * 盘上存的键认回一家。认不出来落 [DEEPSEEK]：老用户升级上来盘上没有
         * `provider_*` 键，读出来就是默认那家 —— 与「新字段不翻转旧值」的既有约定一致。
         */
        fun fromKey(key: String?): AiProvider =
            entries.firstOrNull { it.key == key } ?: DEEPSEEK
    }
}
